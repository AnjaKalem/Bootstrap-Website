var x = "k"
const xType = parseInt(x);

function proveraBroja(broj) {
            
    if (isNaN(broj)) {
        return false;
    }

    else {
        return 'Validan broj';
    }
} 

// console.log(proveraBroja(xType));

  /*   switch(proveraBroja(xType)) {
    case false : console.log("Morate uneti broj")
    break
    case 'Validan broj' : console.log("Koju racunsku operaciju zelite?")
    break
    } */

/*     switch(proveraBroja(xType)) {
        case false : console.log("Morate uneti broj")
        break
        case 'Validan broj' : 
        break
    } 
 */
    function sabiranje(x, y) {
        return parseInt(x) + parseInt(y);
    } console.log(sabiranje(2, 3))

