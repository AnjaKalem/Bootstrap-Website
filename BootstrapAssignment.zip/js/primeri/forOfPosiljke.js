const posiljke = [
    { adresa: "Adresa 1, Beograd", tezina: 1 },
    { adresa: "Adresa 2, Novi Sad", tezina: 1.3 },
    { adresa: "Adresa 3, Beograd", tezina: 1.5 },
    { adresa: "Adresa 4, Nis", tezina: 0.25 },
    { adresa: "Adresa 5, Subotica", tezina: 0.4 }
]

// Kriterijum : manje od 500g
let rezultat = []
for(let posiljka of posiljke) {
    if(posiljka.tezina < 0.5) {
        rezultat.push(posiljka) // ceo objekat se smesta u novi niz
    }
} console.log(rezultat)

// Kriterijum: tezina <=500g i tezina <= 1kg
let rezultat2 = []
for(let posiljka of posiljke) {
    if(posiljka.tezina >= 0.5 && posiljka.tezina <= 1) {
        rezultat2.push(posiljka)
    }
} console.log("Rezultat2 je", rezultat2)

// Kriterijum : Svi koji su iz Bga
// string.indexOf(fraza) -> -1 ako fraze nema, ili
// neki drugi broj ako fraza postoji
let rezultat3 = []
for(let posiljka of posiljke) {
    if(posiljka.adresa.indexOf("Beograd") != -1) {
        rezultat3.push(posiljka)
    }
} console.log("Rezultat 3 je", rezultat3)
