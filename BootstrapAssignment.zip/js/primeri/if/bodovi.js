// var x = prompt("Unesite broj bodova od 0 do 100")
var x = 230

if (x <= 50) {
    ocena = 5
    console.log("Student nije polozio ispit. Shame")
}
else if( (x >= 51) && ( x <= 60)) {
    ocena = 6
}
else if( (x >= 61) && ( x <= 70)) {
    ocena = 7
}

else if( (x >= 71) && ( x <= 80)) {
    ocena = 8
}

else if( (x >= 81) && ( x <= 90)) {
    ocena = 9
}

else if( (x >= 91) && ( x <= 100)) {
    ocena = 10
}
else {
    ocena = "Izvan opsega"
    console.log("Morate uneti broj izmedju 0 i 100")
}

console.log("Student je dobio ocenu", ocena)