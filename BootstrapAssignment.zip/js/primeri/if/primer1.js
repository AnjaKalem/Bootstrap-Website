const a = 7
const b = 5
const c = 9

if(a > b) {
    // DA grana
    if(a > c) {
        max = a
    } 
    else {
        max = c
    }
}
else {
    // NE grana
    if ( b > c) {
        max = b
    }
    else {
        max = c
    }
}
console.log("Maksimum je ", max)

if( (a >= b) && (a >= c))  {
    max2 = a
}
else if ( (b >= a) && (b >= c)) {
    max2 = b
}
else {
    max2 = c
}

console.log("Maksimum 2 je ", max2)