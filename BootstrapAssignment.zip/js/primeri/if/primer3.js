var cena = 100
var region = "US"

if(region === "EU") {
   cena += 7/100*cena
}
else if(region === "CA") {
    cena += 13/100*cena
    // cena = cena + cena * 1.13
}
else if(region === "UK") {
    cena += 15/100*cena
}
else if ((region === "US") || (region === "CA")) {
    cena += 20/100*cena
}
console.log ("Za region", region, "cena je", cena)