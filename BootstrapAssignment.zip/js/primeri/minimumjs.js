const brojevi = [ 3, 4, 8, 5, 2, 1]

min = brojevi[0]

for(let i = 0; i < brojevi.length; i++) {
    for(let j = i + 1; j < brojevi.length; j++) {
        if(brojevi[i] > brojevi[j]) {
            tmp = brojevi[i]
            brojevi[i] = brojevi[j]
            brojevi[j] = tmp
        }
    }
} console.log(brojevi)

