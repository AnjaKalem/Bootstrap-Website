const niz = [ 18, 24, 12, 38, 64, 25, 22 ]
let suma = 0
for(let g of niz) {
    suma = suma + g
}

sr_vr = suma / niz.length
console.log("Prosecna vrednost godina je", sr_vr)

