const proizvodi = [
    { naziv: "Jogurt", cena: 120 }, 
    { naziv: "Mleko", cena: 64 }, 
    { naziv: "Pavlaka", cena: 40 }, 
    { naziv: "Kajmak", cena: 210 }, 
    { naziv: "Kiselo mleko", cena: 20 }  
]

let jeftino = []

for(let proizvod of proizvodi) {
    if(proizvodi.cena < 100) {
        jeftino.push(proizvod)
    }
} console.log("Pristupacni proizvodi su:", jeftino)

// sortiranje po opadajucem nizu
for(let i = 0; i < proizvodi.length - 1; i++) {
    for(let j = i + 1; j < proizvodi.length; j++) {
        if(proizvodi[i].cena < proizvodi[j].cena) {
            hlp = proizvodi[i]
            proizvodi[i] = proizvodi[j]
            proizvodi[j] = hlp
        }
    }
} console.log(proizvodi)