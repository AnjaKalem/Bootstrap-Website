const godine = [ 18, 24, 12, 38, 64, 25, 22 ]
let suma = 0
for(let g of godine) {
    suma = suma + g
}

sr_vr = suma / godine.length
console.log("Prosecna vrednost godina je", sr_vr)

max = godine[0] // gadja prvi element niza
for(let i = 1; i < godine.length; i++) {
    if(godine[i] > max) {
        max = godine[i]
    }
}
console.log(max)