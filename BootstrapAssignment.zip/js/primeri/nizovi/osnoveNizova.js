let cars = ["Clio", "BMW", "Nissan", "Smart", "Yugo"]

cars.push("Honda") // dodaje element na kraj niza

cars.unshift("Mazda") // dodaje element na pocetak niza

cars.pop() // uklanja element sa kraja niza

cars.shift() // uklanja element sa pocetka niza

console.log(cars.toString()) // ispisuje niz u vidu stringa

let pos = cars.indexOf("Clio") // dodeljuje promenljivoj index navedenog pojma u nizu
console.log(pos)



