let cars = ["Clio", "BMW", "Nissan", "Smart", "Yugo"]

cars[0] = "Mercedes" // zamena jednog clana niza drugim
console.log(cars.toString())

cars.sort()
console.log(cars.toString)

// console.log(cars[0]) // ispisuje vrednost clana sa indexom 0

// console.log(cars.toString()) // ispisuje sve vrednosti niza u formi Stringa

for(let i=0; i<cars.length; i++) {
     console.log(cars[i])
}