let niz = [3,34,654,22,1,8,17]

niz.sort(compareNumbers)

function compareNumbers(a,b) {
    return a - b
}
console.log(niz.toString())