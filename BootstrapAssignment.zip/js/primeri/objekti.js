const student = { "ime" : "Anja",
                 "prezime" : "Kalem", 
                 "godina": 4, 
                 "kartica za menzu" : true
                }

                console.log("Ime studenta:", student.ime)
                console.log("Prezime studenta:", student.prezime)