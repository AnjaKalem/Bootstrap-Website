console.log("Petlja od 1 do 50, korak 5")
for(let i = 1; i <= 50; i+=5) {
    console.log(i)
}