console.log("Petlja: 20 do -10, korak 4")
for(i = 20; i >= -10; i=i-4) {
    console.log(i)
}