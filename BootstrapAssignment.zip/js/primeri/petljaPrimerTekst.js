const tekst = "Ovo je neki tekst koji se koristi za testiranje"
/* for(let i = 0; i < tekst.length; i++) {
    console.log(tekst.charAt(i))
} */

/* let svaki_drugi = ""
for(let i = 0; i < tekst.length; i=i+2) {
    svaki_drugi += tekst.charAt(i)
}
console.log(svaki_drugi) // petlja uzima svako drugo slovo i stavlja u novi tekst

let obrnut = ""
for(let i = tekst.length - 1; i >= 0; i--){
    obrnut += tekst.charAt(i)
}
console.log("Tekst naopako ", obrnut) */

const podeljen_tekst = tekst.split(" ")
console.log(podeljen_tekst)