console.log("Petlja od 20 do - 10")
for(let i = 20; i >= -10; i = i - 4) {
    console.log(i)
}