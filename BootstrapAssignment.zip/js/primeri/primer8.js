const nekaOsoba = {
    ime: "Pero",
    prezime: "Markovic",
    godina_rodjenja: 1992,
    mail: "peromarkovic@gmail.com",
    adresa: {
        ulica: "Cara Dusana",
        broj: 31,
        postanski_broj: 11000,
        grad: "Beograd"
    }

}

console.log(nekaOsoba.adresa.grad)
console.log( "Godina rodjenja je " + nekaOsoba.godina_rodjenja)
console.log("\tOsobin mail je " + "\n" + nekaOsoba.mail)
console.log("\tpostanski broj:  " +
             nekaOsoba.adresa.postanski_broj + "\n")