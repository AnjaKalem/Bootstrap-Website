const niz_brojeva = [2, 4, 6, 8]
// Pozicije:         0  1  2  3

/* console.log("Element na indexu 3: " + niz_brojeva[3])
console.log("Duzina niza je: ", niz_brojeva.length)
console.log("Poslednji element: ", niz_brojeva[niz_brojeva.length-1]) */

niz_brojeva.push(1, 3) // dodaje na kraj niza elemente
// console.log("Niz posle dodavanja dva broja:", niz_brojeva) 

niz_brojeva.unshift(0, 4) // dodaje na pocetak niza elemente
// console.log("Niz posle dodavanja dva broja: na pocetak", niz_brojeva) 

niz_brojeva.pop() // brise 1 element sa kraja niza
niz_brojeva.shift() // brise 1 element sa pocetka niza
// console.log("Niz posle pop i shift", niz_brojeva)


const poslednji = niz_brojeva.pop() // brise 1 element sa kraja niza
const prvi = niz_brojeva.shift() // brise 1 element sa pocetka niza
// console.log("Niz posle pop i shift", niz_brojeva)
// console.log("Ovo smo izbacili sa pop i shift: " ,poslednji, prvi)


niz_brojeva.splice(2, 0, 15, 16, 17 )  
// umetanje u sred niza (pozicija na koju zelimo da ubacimo, da li zelimo da obrisemo nesto - obavezan parametar obicno 0, dalje ono sto ubavcujemo )
// console.log("Ovo smo umetnuli: ", niz_brojeva)

niz_brojeva.splice(2, 1)
console.log(niz_brojeva)