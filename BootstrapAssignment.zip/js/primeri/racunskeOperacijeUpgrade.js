let x = prompt("Unesite broj ")
let xType = parseInt(x);
console.log(xType)