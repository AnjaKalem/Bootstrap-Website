const komanda = 1

switch(komanda) {
    case 1: 
        console.log("Izabrana je opcija 1")
        break
    case 2:  case 3: 
        console.log("Izabrana je opcija 2 ili 3")
        break

        default: console.log("Nijedna od opcija ne odgovara komandi")
        
} 

const kanal = "N1"

switch(kanal) {
    case "RTS": console.log("Javni medijski servis")
    break
    case "N1": console.log("Strani izdajnici")
    break
    case "Studio B": console.log("Da li to jos postoji?")
    break
    default : console.log("Zao mi je, imate samo tri kanala")
}
