const mesec = "april"

switch(mesec) {
    case "januar" : case "mart" : case "maj" : case "juli" : case "avgust" : case "oktobar" : case "decembar" :
        console.log("Ovaj mesec ima 31 dan")
        break
    case "april" : case "jun" : case "septembar" : case "novembar" :
        console.log("Ovaj mesec ima 30 dana")
        break
    case "februar" : 
    console.log("Ovaj mesec ima 28 ili 29 dana")
    break
    default : console.log("Niste uneli mesec") 
}