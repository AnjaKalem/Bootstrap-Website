
// profesorovo
// 5 meseci(svi dani) + preostali dani u ovom mesecu

const sada = new Date()
const pocetak_god = new Date(2021, 0, 1, 1, 0, 0, 0)

function dani_za_mesec(index_meseca) {
    const dani = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    return dani[index_meseca]
}

function broj_dana_od_pocetka_godine(datum) {
    let ukupno_dana = datum.getDate()

    for(let i = 0; i < datum.getMonth(); i++) {
        ukupno_dana = ukupno_dana + dani_za_mesec(i) 
    }
    return ukupno_dana 
}
console.log(broj_dana_od_pocetka_godine(sada))

function prestupna_godina(godina) {
    if(godina & 400 === 0) {
        return true
    } else if ((godina % 100 != 0) && (godina % 4 == 0)) {
        return true
    } else {
        return false
    }
}

if(prestupna_godina(sada.getFullYear())) {
    ukupno_dana++
} // ako je prestupna godina dodaj jedan dan

// drugi nacin


function broj_dana_2(datum) {
    const prvi_dan = new Date(datum.getFullYear(), 0, 1, 0, 0, 0, 0 )
    const ms1 = datum.getTime()
    const ms2 = prvi_dan.getTime()
    const ms = ms1 - ms2
    return Math.ceil(ms / ( 1000 * 60 * 60 * 24))
}
console.log(broj_dana_2(sada))

