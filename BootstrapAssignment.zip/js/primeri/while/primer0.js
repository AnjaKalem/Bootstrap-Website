let tekuci_broj = 1

while(tekuci_broj <= 100) {
    if(tekuci_broj % 2 === 0) {
        console.log(tekuci_broj)
    } 
    tekuci_broj++
}