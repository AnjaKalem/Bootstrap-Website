let brojac = 0
let tekuci_broj = 1

while(brojac < 100) {
    if((tekuci_broj % 3 === 0) && (tekuci_broj % 7 === 0)) {
        console.log(tekuci_broj)
        brojac++
    }
    tekuci_broj++
}