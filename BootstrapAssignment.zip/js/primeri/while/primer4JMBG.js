const osobe = [
    { ime : "Mirjana", prezime : "Kalem", jmbg : "001"},
    { ime : "Anja", prezime : "Kalem", jmbg : "002"},
    { ime : "Moma", prezime : "Kalem", jmbg : "003"},
    { ime : "Dona", prezime : "Kalem", jmbg : "004"},
    { ime : "Frenk", prezime : "Kalem", jmbg : "005"}
]

const trazeni_jmbg = "002"

 for(let osoba of osobe) {
     console.log(osoba.ime)
    if(osoba.jmbg === trazeni_jmbg) {
            console.log("Trazeno ime je:", osoba.ime)
            break // kad nadje osobu zaustavlja izvrsavanje
    } 
} 