// ispis datuma po srpski
const sada = new Date()

function dan_za_index(indeks) {
     const dani = ["Ned", "Pon", "Uto", "Sre", "Cet", "Pet", "Sub", "Ned"]
     return dani[indeks]
} 

console.log(dan_za_index(sada.getDay()))

function mesec_za_index(indeks) {
    const meseci = ["Januar", "Februar", "Mart", "April", "Maj", "Jun", "Jul", "Avgust", "Septembar", "Oktobar", "Novembar", "Decembar"]
    return meseci[indeks]
} console.log(mesec_za_index(sada.getMonth()))

function format_rs(datum) {
    const indeks_dani = datum.getDay()
    const indeks_meseci = datum.getMonth()
    const dan = datum.getDate()
    const godina = datum.getFullYear()
    const dan_tekst = dan_za_index(indeks_dani)
    const mesec_tekst = mesec_za_index(indeks_meseci)
    return dan_tekst + ", " + dan + ". " + mesec_tekst + " " + godina + "."
}

console.log(format_rs(sada))