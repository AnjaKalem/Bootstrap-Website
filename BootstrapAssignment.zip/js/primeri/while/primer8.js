const sada = new Date()

const pocetak_god = new Date(2021, 0, 1, 1, 0, 0, 0)

// profesorovo
// 5 meseci(svi dani) + preostali dani u ovom mesecu

function dani_za_mesec(index_meseca) {
    const dani = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    return dani[index_meseca]
}

function broj_dana_od_pocetka_godine(datum) {
    let ukupno_dana = datum.getDate()

    for(let i = 0; i < datum.getMonth(); i++) {
        ukupno_dana = ukupno_dana + dani_za_mesec(i) 
    }
    return ukupno_dana 
}
console.log(broj_dana_od_pocetka_godine(sada))