const sada = new Date();
console.log(sada)

const d1 = new Date("2016-04-04 14:15:00")
console.log(d1)

const d2 = new Date(2018, 4, 3, 16, 0 , 0 , 2)
console.log(d2)

console.log("Indeks meseca:", sada.getMonth())
console.log("Dan u mesecu:", sada.getDate())
console.log("Index dana u nedelji:", sada.getDay())
console.log("Sati:", sada.getHours())
console.log("Minuta:", sada.getMinutes())

const ms1 = sada.getTime()
const ms2 = d2.getTime()
const ms = ms1 - ms2
console.log(ms / ( 1000 * 60 * 60 * 24)) // broj dana 