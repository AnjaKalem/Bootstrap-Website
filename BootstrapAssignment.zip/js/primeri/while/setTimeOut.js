function zdravo() {
    console.log("Zdravo")
}

/* setTimeout(zdravo, 5000) */

setInterval(zdravo, 2000)