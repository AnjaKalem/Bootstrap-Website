// Zamena vrednosti promenljivih

a = 5
b = 3

c = a 
a = b
b = c

console.log(a, b)